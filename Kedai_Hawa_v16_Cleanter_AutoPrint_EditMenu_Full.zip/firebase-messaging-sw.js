// Push notification service worker akan diaktifkan pada tahap notifikasi.
